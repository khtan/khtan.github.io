#!/bin/sh -x
echo "hello"
bin/debug/dailyrate.exe <<!
44.5
10
!