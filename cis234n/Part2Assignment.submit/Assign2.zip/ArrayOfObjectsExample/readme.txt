Since this is a console application, I have dispensed completely with
VS .NET's solution and project overhead and just provided the source
and executable.

The advantage is smaller download.

Sample Transcript
------------------
// Compile
H:\vault\learn\pcc\cis234n\Part2Assignment\ArrayOfObjectsExample>csc arrayofObjectsExample.cs 
csc arrayofObjectsExample.cs 
Microsoft (R) Visual C# .NET Compiler version 7.10.3052.4
for Microsoft (R) .NET Framework version 1.1.4322
Copyright (C) Microsoft Corporation 2001-2002. All rights reserved.

// Run
H:\vault\learn\pcc\cis234n\Part2Assignment\ArrayOfObjectsExample>arrayOfObjectsExample.exe 
arrayOfObjectsExample.exe 
(5,10)
(27,36)
