Since this is a console application, I have dispensed completely with
VS .NET's solution and project overhead and just provided the source
and executable.

The advantage is smaller download.

Sample Transcript
------------------
// Compile
h:\vault\learn\pcc\cis234n\Part2Assignment\Automobile>csc automobile.cs
csc automobile.cs
Microsoft (R) Visual C# .NET Compiler version 7.10.3052.4
for Microsoft (R) .NET Framework version 1.1.4322
Copyright (C) Microsoft Corporation 2001-2002. All rights reserved.

// Run
h:\vault\learn\pcc\cis234n\Part2Assignment\Automobile>automobile.exe
automobile.exe
Running Automobile
Start of circuit, did not finish drive of 0 miles,  Car:rx7 Tank:0
After filling up,  Car:rx7 Tank:10
After driving 14.7 miles,  Car:rx7 Tank:8.53
After driving 60.7 miles,  Car:rx7 Tank:2.46
Oh oh! Out of gas
After driving 33.7 miles, did not finish drive of 33.7 miles,  Car:rx7 Tank:0
