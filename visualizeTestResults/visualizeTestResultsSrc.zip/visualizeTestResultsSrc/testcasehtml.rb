#
=begin rdoc
  testcasehtml.rb - generate html and style sheet for testcaseresults
  Author: Kwee Heong Tan

  The testcaseresult can be configured by changing its testcasehtml.config.yaml
  file.

  The default configuration is defined as follows :
     :include: testcasehtml.config.yaml
=end
require 'yaml'
require 'pp'
require 'rexml/document'
include REXML
$:.unshift File.join(File.dirname(__FILE__),"..")
require 'testcaseutils.rb'

class TestcaseHtml
=begin rdoc
Reads yaml-based configuration file
   convention - name of configuration file     : <class file>config.yaml
   convention - location of configuration file : same as <class file>.rb
   Returns configuration hashes to be assigned to class constants
=end
  def self.loadConfig
    begin
      configfile=File.basename(__FILE__,'.rb')+".config.yaml"
      configpath=File.join(File.dirname(__FILE__),configfile)
      confighash=YAML::load_file(configpath)
      return confighash
    rescue SystemCallError
      $stderr.print "ERROR: Unable to find required configuration : " + $!
    rescue ArgumentError => e
      $stderr.print "ERROR: Unable to parse required configuration #{configpath}\n"
      raise
    end
  end
# class constants, using bootstrap loadConfig
  CONFIG=loadConfig
# 
    def initialize
      @tNameSeen=Hash.new(0) # testcaseName
      @pNameSeen=Hash.new(0) # platform
      @bNumSeen=Hash.new(0)  # buildNum
      @table=Hash.new
    end # initialize
    def dumpTable # :nodoc:
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           sd.each { |k,v|
              print "tc=#{tc} mc=#{mc} k=#{k} v=#{v}\n"
           }
         }
      }
    end # def dumpTable
    def printDebug # :nodoc:
      print "@tNameSeen.inspect="
      puts @tNameSeen.inspect
      print "@pNameSeen.inspect="
      puts @pNameSeen.inspect
      print "@bNumSeen.inspect="
      puts @bNumSeen.inspect
      # print "@table="
      # pp @table.inspect
      dumpTable
    end # def printDebug
=begin rdoc
Read list of yamlFiles containing TestcaseResults, into internal data structures
=end
    def readYaml(*yamlFiles)
      countDiscrepancy=0
      yamlFiles.each { |yamlFile|
      print "yamlFile=#{yamlFile}\n"
         fileFH=File.open(yamlFile,"r")

         yamlFH=YAML::load_documents(fileFH){ |tr| # tr == test result
            tc,mc,ts,bn=tr.testcaseName,tr.machineName,tr.runStatus,tr.buildNum
            pn=TestcaseUtils::machineToPlatform(mc)
            if pn=="unknown"
              $stderr.print "WARN: Unknown platform for machine #{mc}\n"
            end
#            sd=Date.new(tr.startDateTime.year,tr.startDateTime.month,tr.startDateTime.day)
#            sdNeeded=sd.day.to_s
            @tNameSeen[tc]+=1
            @pNameSeen[pn]+=1
            @bNumSeen[bn]+=1

            if @table[tc] == nil
              @table[tc]={pn=>{bn=>ts}}
            else
              if @table[tc][pn] == nil
                @table[tc][pn]={bn=>ts}
              else
                 if @table[tc][pn][bn] == nil
                   @table[tc][pn][bn]=ts
                 else
                   oldts=@table[tc][pn][bn]
                   if CONFIG['conflictreaction'] == "exit"
                     $stderr.print "ERROR: Discrepancy for [#{tc}][#{pn}][#{bn}] old=#{oldts},new=#{ts}\n"
                     exit
                   elsif CONFIG['conflictreaction'] == "warn"
                     $stderr.print "WARN: Discrepancy for [#{tc}][#{pn}][#{bn}] old=#{oldts},new=#{ts}\n"
                   elsif CONFIG['conflictreaction'] == "count"
                      countDiscrepancy+=1
                   end
                   if CONFIG['TESTSTATUSUPDATE'].include?(CONFIG['teststatusupdate'])
                       if CONFIG['teststatusupdate'] != "first"
                         reverse=CONFIG['teststatusupdate']=="optimistic"? true:false
                         if CONFIG['teststatusupdate']=="last" or TestcaseResult::compareStateKey(oldts,ts,reverse) < 0
                           @table[tc][pn][bn]=ts
                           $stderr.print "WARN: updated\n" if CONFIG['conflictreaction'] == "warn"
                         end
                       end
                   else
                       $stderr.print "ERROR: Incorrect option for CONFIG['teststatusupdate']"
                   end
                 end
              end
            end
         } # yamlFile
         fileFH.close
      } # yamlFiles.each
      if countDiscrepancy > 0
        $stderr.print "WARN: #{countDiscrepancy} discrepancies detected.\n"
      end
    end # def readYaml(yamlFile)
    def getTableHeader # :nodoc:
      t=REXML::Element.new("table")
      # t.attributes["border"]=0;
      t.attributes['class']='tc'
#      h=t.add_element "tr", {"bgcolor"=>CONFIG['headerBgcolor']}
      h=t.add_element "tr"
#      h11=h.add_element "th", {"align"=>"left"}
      h11=h.add_element "th"
      nbspTestcase=Text.new("&nbsp; Testcase &nbsp;",true,nil,true)
      h11.text=nbspTestcase
#      h12=h.add_element "th", {"align"=>"left"}
      h12=h.add_element "th"
      nbspMachine=Text.new("&nbsp; Platform &nbsp;",true,nil,true)
      h12.text=nbspMachine

      @bNumSeen.keys.sort.each { |d|
#         h12=h.add_element "th", {"align"=>"left"}
         h12=h.add_element "th"
         h12.text=d
      }
      return t
    end # def getTableHeader
    def getKeyHeader # :nodoc:
      tT=REXML::Element.new("table")
      tR=tT.add_element "tr"
      tH=tR.add_element "th"
      tH.text="KEY:"
      TestcaseResult::STATEARRAY.each { |c|
         s=TestcaseResult::INVSTATEHASH[c]
         tH=tR.add_element "th"
         tH.attributes['class']="tc-#{c}"
         tH.text="#{c}==#{s}"
      }
=begin
      TestcaseResult::STATEHASH.each { |s,c|
         tH=tR.add_element "th"
         tH.attributes['class']="tc-#{c}"
         tH.text="#{c}==#{s}"
      }
=end
      return tT
    end 
=begin rdoc
Return HTML table, constructed after internal structures have been populated with readYaml
=end
    def getTable # :nodoc:
      tH=getTableHeader
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           tR=tH.add_element "tr"
           tD=tR.add_element "td"
           tD.text=tc
           tD=tR.add_element "td"
           tD.text=mc
           @bNumSeen.keys.sort.each { |d|
           tD=tR.add_element "td"
              if @table[tc][mc][d] != nil
                 # tD.attributes["bgcolor"]=TestcaseResult::STATECOLOR[@table[tc][mc][d]]
                 tD.attributes['class']="tc-#{@table[tc][mc][d]}"
                 tD.text=@table[tc][mc][d]
              else
                 tD.text='-'
              end
           }
         }
      }
      return tH
    end 
    def writeStyleHtml(fH,cssFile) # :nodoc:
       baseCssFile=File.basename(cssFile)
   s=<<END_OF_STRING
<style type="text/css"><!--
   @import url(\"#{baseCssFile}\");
--></style>
END_OF_STRING
       fH.print s    
    end
=begin rdoc
Write out html file and reference to style sheet.
=end
    def outputHtml(htmlFile,cssFile)
      begin
        htmlHandle=File.open(htmlFile,"w")
        writeStyleHtml(htmlHandle,cssFile)
        tH=getTable
        tH.write(htmlHandle,0)
        br=REXML::Element.new("br")
        br.write(htmlHandle,0)
        br.write(htmlHandle,0)
        tK=getKeyHeader
        tK.write(htmlHandle,0)
      rescue SystemCallError
       $stderr.print "IO failed:" + $!
      end
    end # def outputHtml(htmlFile)
    def writeStyleSheet(fH) # :nodoc:
s=<<END_OF_STRING
table.tc {border:0}
table.tc th {background-color:#9acd32}
END_OF_STRING
      fH.print s
      TestcaseResult::STATEARRAY.each {|s| 
         color=TestcaseResult::STATECOLOR[s]
         fH.print ".tc-#{s} {background-color:#{color}}\n"
      }
    end # def writeStyleSheet(fH)
=begin rdoc
Write out style sheet.
=end
    def outputStyleSheet(cssFile)
       begin
          cssHandle=File.open(cssFile,"w")
          writeStyleSheet(cssHandle)
       rescue SystemCallError
         $stderr.print "IO failed:" + $!
       end
    end # def outputStyleSheet(cssFile)
=begin rdoc
=end
    def run(htmlFile,cssFile,*yamlFiles)
#      print "run(htmlFile=#{htmlFile},cssFile=#{cssFile},yamlFiles=#{yamlFiles.join('-')})\n"
      readYaml(*yamlFiles)
      outputHtml(htmlFile,cssFile)
      outputStyleSheet(cssFile)
    end # def run
end # class TestcaseHtml
__END__
Generate html table from yaml input files
getTableHeader
   usse class variable or return the reference to object
   will object go out of scope?
11/06/08 Thu list of yamlFiles
   use * in argument or use an array?
   expanding arrays in method calls pp107
11/06/08 Thu using dateStart can collide
   use buildNo instead
11/06/08 Thu add color to status
  where should color map be? testcaseresult
11/06/08 Thu column sizing
  currently column "Testcase" is sized exactly.
  width attribute is in pixels or % - deprecated
  &nbsp; works but rexml does not write out correctly
  have to define entity before using it
  Text.new documentation not very clear
