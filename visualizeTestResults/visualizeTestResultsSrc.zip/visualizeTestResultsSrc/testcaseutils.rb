# 
=begin rdoc
  testcaseutils.rb - utilities for testcaseresult
  Author: Kwee Heong Tan

  The testcaseutils should be configured by changing its testcaseutils.config.yaml
  file for each specific team or site.

  The default configuration is defined as follows :
     :include: testcaseutils.config.yaml
=end
require 'yaml'
require 'testcaseresult.rb'

class TestcaseUtils
=begin rdoc
Reads yaml-based configuration file
   convention - name of configuration file     : <class file>config.yaml
   convention - location of configuration file : same as <class file>.rb
   Returns configuration hashes to be assigned to class constants
=end
  def self.loadConfig
    begin
      configfile=File.basename(__FILE__,'.rb')+".config.yaml"
      configpath=File.join(File.dirname(__FILE__),configfile)
      confighash=YAML::load_file(configpath)
      return confighash
    rescue SystemCallError
      $stderr.print "ERROR: Unable to find required configuration : " + $!
    rescue ArgumentError => e
      $stderr.print "ERROR: Unable to parse required configuration #{configpath}\n"
      raise
    end
  end
# class constants
  CONFIG=loadConfig
  PLAT=CONFIG['PLAT']
  MACHINES=PLAT.keys
=begin rdoc
Produce a human readable time units for days, hours, min, secs

Eg 3662s => 1h1m2s

   timeDiff : in seconds

=end
   def self.readableTimeDiff(timeDiff)
     # converted from Perl f:/synopsys/projects/BTb/trunk/lib/Process/Utility.pm of same name
     days,hours,min,sec,timeDiffA,timeDiffB=0,0,0,0,0,0
     days=(timeDiff/86400).truncate
     timeDiffA=timeDiff%86400
     hours=(timeDiffA/3600).truncate
     timeDiffB=timeDiffA%3600
     min=(timeDiffB/60).truncate
     sec=timeDiffB%60

     # print("td=timeDiff,d=days,h=hours,m=min,s=sec,A=timeDiffA,B=timeDiffB\n");
     rString= (0!=days)? "#{days}d ":""
     rString+= (0!=hours)? "#{hours}h ":""
     rString+= (0!=min)? "#{min}m ":""
     rString+= (0!=sec)? "#{sec}s":""
     rString="0s" if(rString == "")
     return rString
   end #self.readableTimeDiff(timeDiff)
=begin rdoc
Return the platform of a given machine
=end
   def self.machineToPlatform(machine)
      if PLAT[machine] == nil
        return "unknown";
      else
        return PLAT[machine]
      end
   end #self.machineToPlatform(machine)
end # class TestcaseUtils
