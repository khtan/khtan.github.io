#!/usr/bin/ruby
require 'rubygems'
require 'gruff'

#g=Gruff::Line.new
#g=Gruff::SideBar.new
g=Gruff::SideStackedBar.new
g.title="My Test Graph"
g.x_axis_label="x axis label"
g.y_axis_label="y axis label"
g.hide_line_markers=false  # misnomer, don't see any line markers being hidden
g.data("apples",["10/01","10/02","10/03"])
#g.data("oranges",[2,2,2,2,2,2])
#g.data("watermelon",[3,3,3,3,3,3])
#g.data("peaches",[4,4,4,4,4,4])
g.labels={0=>'Test1',2=>'Test2',4=>'Test3'}
g.write('testgruff.png')
