require 'test/unit'
require 'optparse'
require 'date'
require 'pp'
$:.unshift File.join(File.dirname(__FILE__),"..")
require "testcasehtml.rb"

class Test_TestcaseResult < Test::Unit::TestCase
   def xtest_one
      tc=TestcaseResult.new("sun1","array","2008-10-01 16:00:00","5",TestcaseResult::STATEHASH['passed'])
      puts tc.inspect
   end # test_one
   def xtest_machineToPlatform
     listMachines=['sun1','sun2','sun3','win2k1','hello']
     listMachines.each {|m| print "#{m} #{TestcaseUtils.machineToPlatform(m)}\n" }
   end # test_machineToPlatform
   def xtest_sequentialrun
     OptionParser.accept(Date,%r{(\d+)[-/](\d+)[-/](\d+)}) do |d,mon,day,year|
         # print "d==#{d} mon=#{mon} day=#{day} year=#{year}"
         Date.new(year.to_i,mon.to_i,day.to_i)
      end
      opts=OptionParser.new
      optHash=Hash.new
      opts.on("-y=PATH","--yamlfile=PATH", String) {|val| optHash['-y']=val}
      opts.on("-a=DATE","--at=DATE", Date) {|val| optHash['-a']=val}
      opts.on("-n=NUM","--num=NUM",Integer){|val| optHash['-n']=val}
      opts.parse!(ARGV)
      assert(false,"Need to specify -y") if (optHash['-y']==nil)
      assert(false,"Need to specify -a") if (optHash['-a']==nil)
      assert(false,"Need to specify -n") if (optHash['-n']==nil)
      tcU=TestcaseUtils.new
      tcU.fullsequentialrun(optHash['-y'],optHash['-a'],optHash['-n'])
   end # test_sequentialrun
   def xtest_STATE
      pp TestcaseResult::STATEHASH
      pp TestcaseResult::STATEARRAY
      pp TestcaseResult::STATECOLOR
   end 
   def xtest_compareState
      pp TestcaseResult.compareStateKey('P','F')
      pp TestcaseResult.compareStateValue('passed','failed')
      tarray=['P','F','A','P','F','A']
      print "tarray=="
      pp tarray
      print "tarray.sort with compareKey(x,y) =="
      pp tarray.sort {|x,y| TestcaseResult.compareStateKey(x,y)}
      print "tarray.sort with compareKey(x,y,false) =="
      pp tarray.sort {|x,y| TestcaseResult.compareStateKey(x,y,false)}
      print "tarray.sort with compareKey(x,y,true) =="
      pp tarray.sort {|x,y| TestcaseResult.compareStateKey(x,y,true)}
   end
   def test_testcasehtml
      htmlFile="data/long.htm"
      cssFile="data/long.css"
      g=TestcaseHtml.new
#      g.readYaml(*["oct20.yaml","oct21.yaml","oct22.yaml","oct23.yaml"])
#      g.readYaml(*["data/2008-10-01.yaml","data/2008-10-02.yaml","data/2008-10-03.yaml","data/2008-10-04.yaml","data/2008-10-05.yaml","data/2008-10-06.yaml","data/2008-10-07.yaml","data/2008-10-08.yaml","data/2008-10-09.yaml","data/2008-10-10.yaml"])
      g.readYaml(*Dir.glob("data/2008-*"))
      g.outputHtml(htmlFile,cssFile)
      g.outputStyleSheet(cssFile)
   end # def test_testcasehtml
   def xtest_getstatusdistri
      tcU=TestcaseUtils.new
      n=0
      10.times do
        v=tcU.getStatusDistribution(n)
        print "n=#{n} v=#{v}\n"
      end
   end # def test_getstatusdistri
   def xtest_runfordays
      tcU=TestcaseUtils.new
      sD=Date.new(2008,10,1)
      eD=Date.new(2008,10,10)
      tcU.runForDays(sD,eD,4)
   end # def test_runfordays
   def xtest_longrun
      tcU=TestcaseUtils.new
      sD=Date.new(2008,11,1)
      eD=Date.new(2008,12,31)
      initialBuildNo=37
      tcU.runForDays(sD,eD,initialBuildNo)
   end
end
