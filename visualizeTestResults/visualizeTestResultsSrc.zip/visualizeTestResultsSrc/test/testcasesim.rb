# 
=begin rdoc
  testcasesim.rb - simulate testcaseresults for testing purposes
  Author: Kwee Heong Tan
  Documentation: Kwee Heong Tan

  The testcasesim should be configured by changing its testcasesim.config.yaml
  file for each specific team or site.

  The default configuration is defined as follows :
     :include: testcasesim.config.yaml
=end
require 'date'
require 'testcaseutils.rb'

class TestcaseSim
=begin rdoc
Reads yaml-based configuration file
   convention - name of configuration file     : <class file>config.yaml
   convention - location of configuration file : same as <class file>.rb
   Returns configuration hashes to be assigned to class constants
=end
  def self.loadConfig
    begin
      configfile=File.basename(__FILE__,'.rb')+".config.yaml"
      configpath=File.join(File.dirname(__FILE__),configfile)
      confighash=YAML::load_file(configpath)
      return confighash
    rescue SystemCallError
      $stderr.print "ERROR: Unable to find required configuration : " + $!
    rescue ArgumentError => e
      $stderr.print "ERROR: Unable to parse required configuration #{configpath}\n"
      raise
    end
  end
# class constants
  CONFIG=loadConfig
  TESTCASES=CONFIG['TESTCASES']
=begin rdoc
Simulate random state of testcase based on internal distribution
   num : select specific internal distribution, 0 to 4 ( currently )
   returns : index into STATEARRAY
=end
   def getStatusDistribution(num)
      distribution=[
         ['P','P','P','P','P','P','P','P','P','P','F'], # mostly pass
         ['P'],  # all pass
         ['P','P','P','F','F','A'], # mostly fail
         ['F'], # all fail
         ['P','P','P','P','P','P','F','F','F','F','F','S','A','K'], # mixed
      ]
     rindex=rand(distribution[num].length)
#     print "getStatusDistribution(#{num}) called. rindex=#{rindex}\n"
     rstate=distribution[num][rindex]
     return TestcaseResult::STATEARRAY.index(rstate)
   end # def getStatusDistribution
=begin rdoc
Generate a sequential run
=end
   def sequentialrun(numOfRuns,machine,yamlfile,startDate,buildNum)
     baseTime=Time.local(startDate.year,startDate.month,startDate.day,16,0,0)
     newTime=baseTime
       yamlFile=File.open(yamlfile,"a") do |yf|
            numOfRuns.times do |i|
              testcase=TESTCASES[i]
#              randomState=rand(TestcaseResult::STATEHASH.length)
              randomState=getStatusDistribution(testcase.length % 5)
              randomDuration=rand(8*60*60) # up to 8 hrs, 8*60*60
#              print "randomDuration=#{randomDuration} or #{self.class.readableTimeDiff(randomDuration)}\t"
#              print "newTime=",newTime.strftime("%Y-%m-%d %H:%M:%S"),"\n"
              tc2=TestcaseResult.new(machine,testcase,newTime,randomDuration,TestcaseResult::STATEARRAY[randomState],buildNum)
              newTime=newTime+randomDuration
#              puts tc2.inspect
              YAML.dump(tc2,yf)
           end # numOfRuns.times
        end # |yf|
   end # sequentialrun(numOfRuns)
=begin rdoc
Generate a full sequential run for all machines in MACHINES
=end
   def fullsequentialrun(yamlFile,startDate,buildNum)
     print "fullsequentialrun(#{yamlFile},#{startDate},#{buildNum})\n"
      TestcaseUtils::MACHINES.each do |m|
         sequentialrun(TESTCASES.length,m,yamlFile,startDate,buildNum)
      end # MACHINES.each
   end # fullsequentialrun
=begin rdoc
Run fullsequentialrun from startDate to endDate

Call tree:
   runForDays(startDate,endDate,startBNum)
   -calls-> fullsequentialrun(yamlFile,startDate,buildNum)
            -calls-> sequentialrun(numOfRuns,machine,yamlfile,startDate,buildNum)
                     -calls-> getstatusDistribution(num)
=end
   def runForDays(startDate,endDate,startBNum)
     outputDir="data1/"
     (startDate .. endDate).each { |d|
        fullsequentialrun(outputDir + d.to_s + ".yaml",d,startBNum+=1)
     }
   end # def runForDays
=begin rdoc
Entry point for commandline use of this class.
Used by genSim.rb and genSim.bat.
=end
   def run(startDateString,endDateString,initialBuildNum)
     (month,day,year)=startDateString.split(/\//)
     if((month != nil) && (day != nil) && (year != nil))
       sD=Date.new(year.to_i,month.to_i,day.to_i)
       (month,day,year)=endDateString.split(/\//)
       if((month != nil) && (day != nil) && (year != nil))
         eD=Date.new(year.to_i,month.to_i,day.to_i)
         runForDays(sD,eD,initialBuildNum.to_i)
       else
         $stderr.print "Error! invalid endDate. Format should be MM/DD/YYYY\n"
       end
     else
       $stderr.print "Error! invalid startDate. Format should be MM/DD/YYYY\n"
       exit
     end
   end # def run
end # class TestcaseSim
