require 'yaml'
require 'pp'
require 'rexml/document'
include REXML
$:.unshift File.join(File.dirname(__FILE__),"..")
require 'testcaseresult.rb'

class GenHtml
    def initialize
      @tNameSeen=Hash.new(0)
      @mNameSeen=Hash.new(0)
      @bNumSeen=Hash.new(0)
      @table=Hash.new
    end # initialize
    def printDebug
      print "@tNameSeen.inspect="
      puts @tNameSeen.inspect
      print "@mNameSeen.inspect="
      puts @mNameSeen.inspect
      print "@bNumSeen.inspect="
      puts @bNumSeen.inspect
      # print "@table="
      # pp @table.inspect
      dumpTable
    end # def printDebug
    def readYaml(*yamlFiles)
      yamlFiles.each { |yamlFile|
         fileFH=File.open(yamlFile,"r")
         yamlFH=YAML::load_documents(fileFH){ |tr| # tr == test result
            tc,mc,ts,bn=tr.testcaseName,tr.machineName,tr.runStatus,tr.buildNum
#            sd=Date.new(tr.startDateTime.year,tr.startDateTime.month,tr.startDateTime.day)
#            sdNeeded=sd.day.to_s
            @tNameSeen[tc]+=1
            @mNameSeen[mc]+=1
            @bNumSeen[bn]+=1
            if @table[tc] == nil
              @table[tc]={mc=>{bn=>ts}}
            else
              if @table[tc][mc] == nil
                @table[tc][mc]={bn=>ts}
              else
                 if @table[tc][mc][bn] == nil
                   @table[tc][mc][bn]=ts
                 else
                   $stderr.print "WARN: Discrepancy for [#{tc}][#{mc}][#{bn}] old=#{@table[tc][mc][bn]},new=#{ts}\n"
                 end
              end
            end
         } # yamlFile
         fileFH.close
      } # yamlFiles.each
    end # def readYaml(yamlFile)
    def getTableHeader
      t=REXML::Element.new("table")
      t.attributes["borders"]=1;
      h=t.add_element "tr", {"bgcolor"=>"#9acd32"}
      h11=h.add_element "th", {"align"=>"left"}
      nbspTestcase=Text.new("&nbsp; Testcase &nbsp;",true,nil,true)
      h11.text=nbspTestcase
      h12=h.add_element "th", {"align"=>"left"}
      nbspMachine=Text.new("&nbsp; Machine &nbsp;",true,nil,true)
      h12.text=nbspMachine

      @bNumSeen.keys.sort.each { |d|
         h12=h.add_element "th", {"align"=>"left"}
         h12.text=d
      }
      return t
    end # def getTableHeader
    def dumpTable
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           sd.each { |k,v|
              print "tc=#{tc} mc=#{mc} k=#{k} v=#{v}\n"
           }
         }
      }
    end #     def dumpTable
    def outputHtml(htmlFile)
      tH=getTableHeader
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           tR=tH.add_element "tr"
           tD=tR.add_element "td"
           tD.text=tc
           tD=tR.add_element "td"
           tD.text=mc
           @bNumSeen.keys.sort.each { |d|
          tD=tR.add_element "td"
              if @table[tc][mc][d] != nil
                 tD.attributes["bgcolor"]=TestcaseResult::STATECOLOR[@table[tc][mc][d]]
                 tD.text=@table[tc][mc][d]
              else
                 tD.text='-'
              end
           }
         }
      }
      begin
        htmlHandle=File.open(htmlFile,"w")
        tH.write(htmlHandle,0)
      rescue SystemCallError
       $stderr.print "IO failed:" + $!
      end
    end # def outputHtml(htmlFile)
end # class GenHtml

g=GenHtml.new
g.readYaml(*["oct10.yaml","oct11.yaml","oct12.yaml","oct13.yaml"])
g.outputHtml("test_testcaseresult.htm")

__END__
Generate html table from yaml input files
getTableHeader
   usse class variable or return the reference to object
   will object go out of scope?
11/06/08 Thu list of yamlFiles
   use * in argument or use an array?
   expanding arrays in method calls pp107
11/06/08 Thu using dateStart can collide
   use buildNo instead
11/06/08 Thu add color to status
  where should color map be? testcaseresult
11/06/08 Thu column sizing
  currently column "Testcase" is sized exactly.
  width attribute is in pixels or % - deprecated
  &nbsp; works but rexml does not write out correctly
  have to define entity before using it
  Text.new documentation not very clear
