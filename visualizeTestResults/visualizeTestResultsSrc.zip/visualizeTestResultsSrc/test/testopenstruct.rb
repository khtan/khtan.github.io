require 'ostruct'
record=OpenStruct.new
record.name="John Smith"
record.age=70
record.pension=300

p record
