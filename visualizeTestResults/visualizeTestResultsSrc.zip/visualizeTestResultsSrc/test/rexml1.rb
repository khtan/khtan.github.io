require "rexml/document"
include REXML
def X
   doc=REXML::Document.new(File.new("sample1.htm","r"))
   puts "Root element: #{doc.root.name}"
end
def writeStyle(cssFile)
   s=<<END_OF_STRING
<style type="text/css"><!--
   @import url(\"#{cssFile}\");
--><style>
END_OF_STRING
  cssFile.print s
end

def test1(cssFile)
  writeStyle(cssFile)
  t=REXML::Element.new("table")
  t.attributes["borders"]=1;
  h=t.add_element "tr", {"bgcolor"=>"#9acd32"}
  h11=h.add_element "th", {"align"=>"left"}
  h11.text="Testcase"
  h12=h.add_element "th", {"align"=>"left"}
  h12.text="10/01"
  r=t.add_element "tr"
  r11=r.add_element "td"
  r11.text="array"
  r12=r.add_element "td"
  r12.text="K"
  t.write(STDOUT,0)
end
# test1("test.css")
#writeFile("x.txt")
#writeFileHandle()
fH=File.open("x.txt","w")
writeStyle(fH)
__END__
1) fn should accept file or filehandle
   File.open already takes fileName or fileDescriptor
   How to check whether it is fileName or fd

   File.open(fN,"+a")

def writeFile(fileName)
  fH=File.open(fileName,"+a")
  print fH "writeFile(#{fileName})\n"
  
end
def writeFH(fHandle)
  fH=File.open(fHandle,"+a")
  print fH "writeFile(#{fileName})\n"
end
