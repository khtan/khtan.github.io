require 'pp'

class Test
  def self.readConfig
     stateA={'passedD'=>'PX','failedD'=>'FX'}
     stateB={'what'=>'gg','name'=>'einstein'}
     return stateA,stateB
  end
  STATEA,STATEB=readConfig
end
pp Test::STATEA
pp Test::STATEB

__END__


