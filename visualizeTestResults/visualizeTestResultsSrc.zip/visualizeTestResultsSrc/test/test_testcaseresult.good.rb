require 'test/unit'
require '../testcaseresult.rb'
require 'yaml'

class Test_TestcaseResult < Test::Unit::TestCase
# class constants
   TESTCASES=["array","hash","io","time","gc","base","object","flatten","join","split"]
#   TESTCASES=["array","hash","io"]
   MACHINES=["sun1","sun2","sun3","sun4","win2k1","winxp1","winxp2"]
#   MACHINES=["sun1","win2k1"]
   def xtest_one
      tc=TestcaseResult.new("sun1","array","2008-10-01 16:00:00","5",TestcaseResult::STATEHASH['passed'])
      puts tc.inspect
   end

   def Test_TestcaseResult.readableTimeDiff(timeDiff)
     # converted from Perl f:/synopsys/projects/BTb/trunk/lib/Process/Utility.pm of same name
     days,hours,min,sec,timeDiffA,timeDiffB=0,0,0,0,0,0
     days=(timeDiff/86400).truncate
     timeDiffA=timeDiff%86400
     hours=(timeDiffA/3600).truncate
     timeDiffB=timeDiffA%3600
     min=(timeDiffB/60).truncate
     sec=timeDiffB%60

     # print("td=timeDiff,d=days,h=hours,m=min,s=sec,A=timeDiffA,B=timeDiffB\n");
     rString= (0!=days)? "#{days}d ":""
     rString+= (0!=hours)? "#{hours}h ":""
     rString+= (0!=min)? "#{min}m ":""
     rString+= (0!=sec)? "#{sec}s":""
     rString="0s" if(rString == "")
     return rString
   end

   def sequentialrun(numOfRuns,machine)
     baseTime=Time.local(2008,10,1,16,0,0)
     newTime=baseTime
        yamlFile=File.open("test_testcaseresult.yaml","a") do |yf|
            numOfRuns.times do |i|
              testcase=TESTCASES[i]
              randomState=rand(TestcaseResult::STATEHASH.length)
              randomDuration=rand(2*60*60) # up to 1 days, 24*60*60
              print "randomDuration=#{randomDuration} or #{Test_TestcaseResult.readableTimeDiff(randomDuration)}\t"
              print "newTime=",newTime.strftime("%Y-%m-%d %H:%M:%S"),"\n"
              tc2=TestcaseResult.new(machine,testcase,newTime,randomDuration,TestcaseResult::STATEARRAY[randomState])
              newTime=newTime+randomDuration
              puts tc2.inspect
              YAML.dump(tc2,yf)
           end # numOfRuns.times
        end # |yf|
   end # sequentialrun(numOfRuns)
   def test_sequentialrun
      MACHINES.each do |m|
         sequentialrun(TESTCASES.length,m)
      end # MACHINES.each
   end
end
