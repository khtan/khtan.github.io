=begin rdoc
Simple empty class for invoking TestcaseHtml::run

Used by genHtml.bat
=end
$:.unshift File.join(File.dirname(__FILE__),"..")
require "testcasehtml.rb"
tH=TestcaseHtml.new
argc=ARGV.length
tH.run(ARGV[0],ARGV[1],*ARGV[2,argc-2])
