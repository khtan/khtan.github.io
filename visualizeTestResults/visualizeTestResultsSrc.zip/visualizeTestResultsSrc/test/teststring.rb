def teststring
   s="hello"
   r="world"
   x=s+" "+r
   puts x
end
teststring
