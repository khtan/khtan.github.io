require 'yaml'
require 'pp'
require 'rexml/document'
include REXML
$:.unshift File.join(File.dirname(__FILE__),"..")
require 'testcaseresult.rb'

class GenHtml
    def initialize
      @tNameSeen=Hash.new(0)
      @mNameSeen=Hash.new(0)
      @sDateSeen=Hash.new(0)
      @table=Hash.new
    end # initialize
    def printDebug
      print "@tNameSeen.inspect="
      puts @tNameSeen.inspect
      print "@mNameSeen.inspect="
      puts @mNameSeen.inspect
      print "@sDateSeen.inspect="
      puts @sDateSeen.inspect
      # print "@table="
      # pp @table.inspect
      dumpTable
    end # def printDebug
    def readYaml(*yamlFiles)
      yamlFiles.each { |yamlFile|
         fileFH=File.open(yamlFile,"r")
         yamlFH=YAML::load_documents(fileFH){ |tr| # tr == test result
            tc,mc,tStatus=tr.testcaseName,tr.machineName,tr.runStatus
            sd=Date.new(tr.startDateTime.year,tr.startDateTime.month,tr.startDateTime.day)
            sdNeeded=sd.day.to_s
            @tNameSeen[tc]+=1
            @mNameSeen[mc]+=1
            @sDateSeen[sdNeeded]+=1
            if @table[tc] == nil
              @table[tc]={mc=>{sdNeeded=>tStatus}}
            else
              if @table[tc][mc] == nil
                @table[tc][mc]={sdNeeded=>tStatus}
              else
                 if @table[tc][mc][sdNeeded] == nil
                   @table[tc][mc][sdNeeded]=tStatus
                 else
                   $stderr.print "Discrepancy for [#{tc}][#{mc}][#{sdNeeded}] old=#{@table[tc][mc][sdNeeded]},new=#{tStatus}\n"
                 end
              end
            end
         } # yamlFile
         fileFH.close
      } # yamlFiles.each
    end # def readYaml(yamlFile)
    def getTableHeader
      t=REXML::Element.new("table")
      t.attributes["borders"]=1;
      h=t.add_element "tr", {"bgcolor"=>"#9acd32"}
      h11=h.add_element "th", {"align"=>"left"}
      h11.text="Testcase"
      h12=h.add_element "th", {"align"=>"left"}
      h12.text="Machine"
      @sDateSeen.keys.sort.each { |d|
         h12=h.add_element "th", {"align"=>"left"}
         h12.text=d
      }
      return t
    end # def getTableHeader
    def dumpTable
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           sd.each { |k,v|
              print "tc=#{tc} mc=#{mc} k=#{k} v=#{v}\n"
           }
         }
      }
    end #     def dumpTable
    def outputHtml(htmlFile)
      tH=getTableHeader
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           tR=tH.add_element "tr"
           tD=tR.add_element "td"
           tD.text=tc
           tD=tR.add_element "td"
           tD.text=mc
           @sDateSeen.keys.sort.each { |d|
              tD=tR.add_element "td"
              if @table[tc][mc][d] != nil
                 tD.text=@table[tc][mc][d]
              else
                 tD.text='-'
              end
           }
         }
      }
      begin
        htmlHandle=File.open(htmlFile,"w")
        tH.write(htmlHandle,0)
      rescue SystemCallError
       $stderr.print "IO failed:" + $!
      end
    end # def outputHtml(htmlFile)
end # class GenHtml

g=GenHtml.new
g.readYaml(*["oct1.yaml","oct2.yaml","oct3.yaml","oct4.yaml"])
g.outputHtml("test_testcaseresult.htm")

__END__
Generate html table from yaml input files
getTableHeader
   usse class variable or return the reference to object
   will object go out of scope?
11/06/08 Thu list of yamlFiles
   use * in argument or use an array?
   expanding arrays in method calls pp107
11/06/08 Thu using dateStart can collide
   use buildNo instead
