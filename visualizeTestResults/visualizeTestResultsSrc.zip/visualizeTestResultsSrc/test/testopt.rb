require 'optparse'

  options = {}
  OptionParser.new do |opts|
    opts.banner = "Usage: example.rb [options]"

    opts.on("-v", "--[no-]verbose", "Run verbosely") do |v|
      options[:verbose] = v
    end
  end.parse!
front.methods
  p options
  p ARGV

__END__
1) p is a Kernel method for running obj.inspect on each object
2) What is end.parse!
