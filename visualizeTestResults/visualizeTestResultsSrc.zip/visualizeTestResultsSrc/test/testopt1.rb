require 'optparse'
opts=OptionParser.new
opts.on("-x") {|val| puts "-x seen"}
opts.on("-s","--size VAL", Integer) {|val| puts "-s #{val}"}
opts.parse! if !ARGV.nil?

p "opts==",opts
p "ARGV==",ARGV if !ARGV.nil?
