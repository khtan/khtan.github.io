require 'optparse'
require 'date'
OptionParser.accept(Date,/(\d+)-(\d+)-(\d+)/) do |d,mon,day,year|
  print "d==#{d} mon=#{mon} day=#{day} year=#{year}"
   Date.new(year.to_i,mon.to_i,day.to_i)
end
opts=OptionParser.new

optHash=Hash.new
opts.on("-x") {optHash['-x']=1}
opts.on("-s","--size VAL", Integer) {|val| optHash['-s']=val}
opts.on("-a=DATE","--at=DATE", Date) {|val| optHash['-a']=val}
opts.parse! if !ARGV.nil?

p "optHash==",optHash
p "ARGV==",ARGV if !ARGV.nil?

