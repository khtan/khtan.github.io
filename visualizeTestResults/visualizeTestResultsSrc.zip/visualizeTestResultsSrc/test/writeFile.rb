def writeFile(fileName)
  x=File.file?(fileName)
  print "fileName.file? #{x}\n"
  fH=File.open(fileName,"a")
 fH.print "writeFile(#{fileName})\n"
end
def writeFH(fHandle)
  x=File.file?(fHandle)
  print "fHandle.file? #{x}\n"
  fHandle.print "writeFile(#{fHandle})\n"
end
writeFile("x.txt")
fH=File.open("y.txt","a")
writeFH(fH)
