=begin rdoc
Simple empty class for invoking TestcaseSim::run

Used by genSim.bat
=end
$:.unshift File.join(File.dirname(__FILE__),"..")
require "testcasesim.rb"
tS=TestcaseSim.new
tS.run(ARGV[0],ARGV[1],ARGV[2])
