require 'yaml'
require 'pp'

def writeYaml(yamlFile)
  config={
     'STATEHASH'=>{'passed'=>'P','failed'=>'F','skipped'=>'S','aborted'=>'A','killed'=>'K'},
     'STATEARRAY'=>['P','F','S','A','K'],
     'STATECOLOR'=>{'P'=>'lightgreen','F'=>'red','S'=>'yellow','A'=>'pink','K'=>'brown'}     
  }
  File.open(yamlFile,"w"){|f| YAML.dump(config,f)}
end
def readYaml(yamlFile)
  begin
    cf=YAML::load_file(yamlFile)
    print "cf "
    pp cf
    cf[PLAT].values
  rescue SystemCallError
       $stderr.print "readYaml failed: " + $!
  end
end

# writeYaml("testYaml.config.yaml")
#readYaml("testYaml.config.yaml")
readYaml(ARGV[0])
