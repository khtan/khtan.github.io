tHash={
   'passed'=>'P',
   'failed'=>'F',
   'skipped'=>'S',
   'aborted'=>'A',
   'killed'=>'K',
}
