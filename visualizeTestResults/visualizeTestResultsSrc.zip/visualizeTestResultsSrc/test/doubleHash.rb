__END__
=====================================================
def test1
  h={
    "io" => {
      "sun1" => "2008-10-01 16:00:00",
      "winxp1" =>"2008-10-02 02:17:14"
    },
    "array" => {
      "sun1" =>"2008-10-02 02:17:14",
      "winxp1" =>"2008-10-01 16:00:00"
    }
  }
  print "#{h['io']['sun1']}\n"
  h['hash']={'sun1'=>"2008-10-03 16:00:00"}
  print "#{h['hash']['sun1']}\n"
  h['hash']={'winxp1'=>"2008-10-04 16:00:00"}
  puts h.inspect
end # test1
def test2
   h=Hash.new
   h['hello']="world"
    h['io,sun1']="2008-10-01 16:00:00"
    h["io,winxp1"]="2008-10-02 02:17:14"
    h["array,sun1"]="2008-10-02 02:17:14"
    h["array,winxp1"]="2008-10-01 16:00:00"
   print "#{h['io,sun1']}\n"
   puts h.inspect
  h.each { |k,v|
    print "k=#{k} v=#{v}\n"
  }
end # test2

test2
=====================================================
Ruby
   allows extraction/reading with multiple indexes
   Eg,   print "#{h['io']['sun1']}\n"
   But to insert, they have to be inserted a hash of hash

Use two hashes yAxis and xAxis

hash[testcaseName,machineName,date]

retrieve with hash[,,date]

Perl experience
  easy to create multi-indexed hash
  the actual key is obtained by combining using "," string
Decision
   Use hash of hash so that retrieval syntax is simple
   Also keep track of keys seen, as array?
      push into an array, what about duplicates?
      use hash
   testcasesNameSeen['testcase']= # if count, can check that all counts are consistent
   machineNameSeen
   startDateSeen

   How to access by row?
   generate first line using startDateSeen
   foreach tc
      foreach mc
         foreach date
            [tc][mc][date] is a test result


Alternatively, create the html table datastructure directly including the header

h[tc]={mc=>{date=>P}}

tableStructure
   headerRow
   contentByRow
   tcSeen

