require 'yaml'
require 'pp'
require 'rexml/document'
include REXML
$:.unshift File.join(File.dirname(__FILE__),"..")
require 'testcaseresult.rb'

class GenHtml
    def initialize
      @tNameSeen=Hash.new(0)
      @mNameSeen=Hash.new(0)
      @sDateSeen=Hash.new(0)
      @table=Hash.new
    end # initialize
    def readYaml(yamlFile)
      fileFH=File.open(yamlFile,"r")
      yamlFH=YAML::load_documents(fileFH){ |tr| # tr == test result
         tc,mc,tStatus=tr.testcaseName,tr.machineName,tr.runStatus
         sd=Date.new(tr.startDateTime.year,tr.startDateTime.month,tr.startDateTime.day)
         @tNameSeen[tc]+=1
         @mNameSeen[mc]+=1
         @sDateSeen[sd.day.to_s]+=1
         if @table[tc] == nil
           @table[tc]={mc=>{sd.day.to_s=>tStatus}}
         else
           if @table[tc][mc] == nil
             @table[tc][mc]={sd.day.to_s=>tStatus}
           else
             @table[tc]={mc=>{sd.day.to_s=>tStatus}}
           end
         end
      }
      print "@tNameSeen.inspect="
      puts @tNameSeen.inspect
      print "@mNameSeen.inspect="
      puts @mNameSeen.inspect
      print "@sDateSeen.inspect="
      puts @sDateSeen.inspect
      print "@table="
      pp @table.inspect
    end # def readYaml(yamlFile)
    def getTableHeader
      t=REXML::Element.new("table")
      t.attributes["borders"]=1;
      h=t.add_element "tr", {"bgcolor"=>"#9acd32"}
      h11=h.add_element "th", {"align"=>"left"}
      h11.text="Testcase"
      h12=h.add_element "th", {"align"=>"left"}
      h12.text="Machine"
      @sDateSeen.keys.sort.each { |d|
         h12=h.add_element "th", {"align"=>"left"}
         h12.text=d
      }
      return t
    end # def getTableHeader
    def dumpTable
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           sd.each { |k,v|
              print "tc=#{tc} mc=#{mc} k=#{k} v=#{v}\n"
           }
         }
      }
    end #     def dumpTable
    def outputHtml(htmlFile)
      tH=getTableHeader
      @table.each { |tc,mcsd|
         mcsd.each { |mc,sd|
           tR=tH.add_element "tr"
           tD=tR.add_element "td"
           tD.text=tc
           tD=tR.add_element "td"
           tD.text=mc
           @sDateSeen.keys.sort.each { |d|
              tD=tR.add_element "td"
              if @table[tc][mc][d] != nil
                 tD.text=@table[tc][mc][d]
              else
                 tD.text='-'
              end
           }
         }
      }

      tH.write(STDOUT,0)
    end # def outputHtml(htmlFile)
end # class GenHtml

g=GenHtml.new
g.readYaml("test_testcaseresult.yaml")
g.outputHtml("test_testcaseresult.html")

__END__
Generate html table from yaml input files
getTableHeader
   usse class variable or return the reference to object
   will object go out of scope?
