#
=begin rdoc
  testcaseresult.rb - encapsulation for a testcase result
  Author: Kwee Heong Tan

  The testcaseresult can be configured by changing its testcaseresult.config.yaml
  file. This allows teams and sites to define what states they are interested in.

  The default configuration is defined as follows :
     :include: testcaseresult.config.yaml
=end
=begin
Requirements
   - testcaseResult object to encapsulate relevant output of testcase run
   - sequentialRun
   - split into several files
        testcaseResult.rb
        sequentialRun.rb
        generateGraph.rb
=end
require 'yaml'
class TestcaseResult
  attr_reader :machineName,:testcaseName,:startDateTime,:runDuration,:runStatus,:buildNum

=begin rdoc
Reads yaml-based configuration file
   convention - name of configuration file     : <class file>config.yaml
   convention - location of configuration file : same as <class file>.rb
   Returns configuration hashes to be assigned to class constants
=end
  def self.loadConfig
    begin
      configfile=File.basename(__FILE__,'.rb')+".config.yaml"
      configpath=File.join(File.dirname(__FILE__),configfile)
      confighash=YAML::load_file(configpath)
      return confighash
    rescue SystemCallError
      $stderr.print "ERROR: Unable to find required configuration : " + $!
    rescue ArgumentError => e
      $stderr.print "ERROR: Unable to parse required configuration #{configpath}\n"
      raise
    end
  end
# class constants, using bootstrap loadConfig
  CONFIG=loadConfig # CONFIG,STATEHASH,STATEARRAY,STATECOLOR=loadConfig
  STATEHASH=CONFIG['STATEHASH']
  STATEARRAY=CONFIG['STATEARRAY']
  STATECOLOR=CONFIG['STATECOLOR']
  INVSTATEHASH=STATEHASH.invert
# class methods
=begin rdoc
Provides comparator for testcase state by key, ie P,F etc
   k1,k2 : keys to compare
   reverse : reverse sense of comparator, to support > and < 
=end
  def self.compareStateKey(k1,k2,reverse=false)
  # eg, k1 == 'P'
    if(reverse==true)
       return STATEARRAY.index(k2) <=> STATEARRAY.index(k1)
    else
       return STATEARRAY.index(k1) <=> STATEARRAY.index(k2)
    end
  end 
=begin rdoc
Provides comparator for testcase state by value, ie 'passed', 'failed'
   s1,s2 : values to compare
   reverse : reverse sense of comparator, to support > and < 
=end
  def self.compareStateValue(s1,s2,reverse=false)
  # eg, s1 == 'passed'
     return compareStateKey(STATEHASH[s1],STATEHASH[s2],reverse)
  end
=begin rdoc
Single constructor, to ensure all testcaseresults objects are complete by construction
=end
    def initialize(machine,testcase,startDateTime,runDuration,runStatus,buildNum)
       @machineName=machine
       @testcaseName=testcase
       @startDateTime=startDateTime
       @runDuration=runDuration
       @runStatus=runStatus
       @buildNum=buildNum
    end # initialize
end # class TestcaseResult
